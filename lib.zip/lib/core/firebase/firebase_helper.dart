import 'package:cloud_firestore/cloud_firestore.dart';

class FirebaseHelper {
 
  static Stream getAllDocStream(
      String path) {
    try {
    
      return Stream.value(5);
    } on FirebaseException catch (e) {
      print("___________Error_____________");
      rethrow;
    }
  }

  static Future<void> addDoc(
      String path, String id, Map<String, dynamic> data) async {
    try {
      
    } on FirebaseException catch (e) {
      rethrow;
    }
  }

  static Future<void> updateDoc(
      String path, String id, Map<String, dynamic> data) async {
    try {
    
    } on FirebaseException catch (e) {
      rethrow;
    }
  }

  static Future<void> removeDoc(String path, String id) async {
    try {
      
    } on FirebaseException catch (e) {
      rethrow;
    }
  }
}
