import 'package:either_dart/either.dart';

import '../../../../core/errors/failure.dart';
import '/../features/salkhana/data/model/member.dart';

abstract class SalkhanaRepository {
  // watch members
  Stream<Either<Failure, List<SalkhanaMemberModel>>> watchMembers(
      String salkhanaSeason);
  Future<Either<Failure, void>> uploadMembersToRemote();
  Future<Either<Failure, void>> downloadMembersToLacal();
  Future<Either<Failure, void>> addMember(
      SalkhanaMemberModel memberModel, String salkhanaSeason);
  // update member
  Future<Either<Failure, void>> updateMember(
      SalkhanaMemberModel memberModel, String salkhanaSeason);
  // remove member
  Future<Either<Failure, void>> removeMember(
      String memberId, String salkhanaSeason);
}
