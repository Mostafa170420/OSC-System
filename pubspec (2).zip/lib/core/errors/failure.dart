class Failure{
  
}